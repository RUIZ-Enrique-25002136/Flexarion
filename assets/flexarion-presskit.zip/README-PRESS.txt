FLEXARION — PRESS KIT / DOSSIER DE PRESSE
=========================================
Studio independant de jeux video base a Aix-en-Provence (France).
Site officiel : https://flexarion.timeoms.fr
Contact : contact@flexarion.timeoms.fr
Fondateurs : Timeo Morsilli (Developpeur), Hugo Banti (Modelisateur 3D), Enrique Ruiz (Developpeur)

Jeux :
- Les Veilleurs de Brume / The Mist Watchers (FLX-01) — Aventure narrative (PC, Godot 4.3, T4 2027)
- Neon Calanques (FLX-02) — Action roguelite (PC / Consoles, Unreal Engine 5, 2028)
- Lisiere (FLX-03) — Puzzle contemplatif (PC / Mobile, Godot 4, 2028)

Palette officielle :
- Noir profond (Ink) : #090909
- Anthracite (Coal)  : #151515
- Blanc casse (Bone) : #F4F2ED
- Orange electrique  : #FF5A1F
- Violet (Pulse)     : #7C4DFF
